<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'IVttcGfO1SVVfyGNqIFUCw');
define('CONSUMER_SECRET', '5VxdYoS87NfrzntD21wgQVmSfEj6y0oGwRJz1goKDLo');
define('OAUTH_CALLBACK', 'http://http://107.20.161.159/retriever/callback.php');
